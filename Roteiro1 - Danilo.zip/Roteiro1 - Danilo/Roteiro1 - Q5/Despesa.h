#ifndef DESPESA_H_INCLUDED
#define DESPESA_H_INCLUDED

#include <iostream>


class Despesa{
    public:
        //atributos
        double valor;
        std::string tipoDeGasto;
        //construtor
        Despesa();
        //metodos
        double getValor();
        std::string getTipoDeGasto();
        void setValor(double val);
        void setTipoDeGasto(std::string tdg);
};
#endif //DESPESA_H_INCLUDED