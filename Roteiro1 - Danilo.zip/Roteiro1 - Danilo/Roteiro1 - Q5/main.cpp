#include "Despesa.h"
#include "ControleDeGastos.h"
#include <iostream>

void menuSetGet(){
    puts("\n~~~~~Utilizar Set e Get~~~~~");
    puts("     1 - Set despesas");
    puts("     2 - Get despesas");
    puts("     3 - Continuar");

    std::cout << "Digite a opcao desejada:";
}
void menuGastos(){
    puts("\n~~~~~Escolha qual o Gasto~~~~~");
    puts("     1 - Gasto1");
    puts("     2 - Gasto2");
    puts("     3 - Continuar");

    std::cout << "Digite a opcao desejada:";
}
void menuSearch(){
    puts("\n~~~~~MENU FINAL~~~~~");
    puts("     1 - Ver se existe um tipo.");
    puts("     2 - Finalizar o sofrimento.");

    std::cout << "Digite a opcao desejada:";
}
void limpa_tela(void){
    #ifdef __unix__
        system("clear");
    #elif WIN32
        system("cls");
    #endif
}

int main(){
    ControleDeGastos gasto1 = ControleDeGastos();
    ControleDeGastos gasto2 = ControleDeGastos();
    Despesa despAux = Despesa();
    
    bool loop = true;
    int menu1, menu2;
    int index;
    double valorAux;
    std::string tipoAux, str;

    while(loop){
        limpa_tela();
        menuGastos();
        std::cin >> menu1;

        switch(menu1){
            case 1:
                menuSetGet();
                std::cin >> menu2;
                switch(menu2){
                    case 1:
                        std::cout << "\nDigite o indice da despesa a ser alterada:";
                        std::cin >> index;
                        std::cout << "Digite o valor da despesa:";
                        std::cin >> valorAux;
                        despAux.valor = valorAux;
                        getchar();//belo e moral
                        std::cout << "Digite o tipo de gasto:";
                        getline(std::cin, tipoAux);
                        despAux.tipoDeGasto = tipoAux;
                        gasto1.setDespesas(despAux, index);
                        break;
                    case 2:
                        std::cout << "\nDigite o indice da despesa a ser vista.";
                        std::cin >> index;
                        getchar();
                        valorAux = gasto1.despesas[index].getValor();
                        tipoAux = gasto1.despesas[index].getTipoDeGasto();
                        std::cout << "Get Valor: " << valorAux << std::endl;
                        std::cout << "Get Tipo: " << tipoAux << std::endl;
                        std::cout << "\nPressione ENTER.";
                        getchar();
                        break;
                    case 3:
                        loop = false;
                        break;
                    default:
                        std::cout << "Opcao invalida, prosseguindo o prog." << std::endl;
                        loop = false;
                        getchar();
                        std::cout << "\nPressione ENTER.";
                        getchar();
                        break;
                }
                break;
            case 2:
                menuSetGet();
                std::cin >> menu2;
                switch(menu2){
                    case 1:
                        std::cout << "\nDigite o indice da despesa a ser alterada:";
                        std::cin >> index;
                        std::cout << "Digite o valor da despesa:";
                        std::cin >> valorAux;
                        despAux.setValor(valorAux);
                        getchar();//belo e moral
                        std::cout << "Digite o tipo de gasto:";
                        getline(std::cin, tipoAux);
                        despAux.setTipoDeGasto(tipoAux);
                        gasto2.setDespesas(despAux, index);
                        break;
                    case 2:
                        std::cout << "\nDigite o indice da despesa a ser vista.";
                        std::cin >> index;
                        getchar();
                        valorAux = gasto2.despesas[index].getValor();
                        tipoAux = gasto2.despesas[index].getTipoDeGasto();
                        std::cout << "Get Valor: " << valorAux << std::endl;
                        std::cout << "Get Tipo: " << tipoAux << std::endl;
                        std::cout << "\nPressione ENTER.";
                        getchar();
                        break;
                    case 3:
                        loop = false;
                        break;
                    default:
                        std::cout << "Opcao invalida, prosseguindo o prog." << std::endl;
                        loop = false;
                        getchar();
                        std::cout << "\nPressione ENTER.";
                        getchar();
                        break;
                }
                break;
            case 3:
                loop = false;
                break;
            default:
                std::cout << "Opcao invalida, prosseguindo o prog." << std::endl;
                loop = false;
                break;
        }
    }
    getchar();
    std::cout << "Pressione ENTER.";
    getchar();
    limpa_tela();

    valorAux = gasto1.calculaTotalDeDespesas();
    std::cout << "Total de gastos do Gasto1: R$ " << valorAux << "\n" << std::endl;
    
    valorAux = gasto2.calculaTotalDeDespesas();
    std::cout << "Total de gastos do Gasto1: R$ " << valorAux << "\n" << std::endl;

    std::cout << "Pressione ENTER.";
    getchar();
    loop = true;

    while (loop){
        bool existencia = false;

        limpa_tela();
        menuSearch();
        std::cin >> menu1;
        
        switch(menu1){
            case 1:
                getchar();
                std::cout << "Digite o tipo:";
                getline(std::cin, tipoAux);
                existencia = gasto1.existeDespesaDoTipo(tipoAux);
                if(existencia == true){
                    std::cout << "Existe este tipo no gasto1" << std::endl;
                }else{
                    std::cout << "Nao existe este tipo no gasto1" << std::endl;
                }

                existencia = gasto2.existeDespesaDoTipo(tipoAux);
                if(existencia == true){
                    std::cout << "Existe este tipo no gasto2" << std::endl;
                }else{
                    std::cout << "Nao existe este tipo no gasto2" << std::endl;
                }
                std::cout << "Pressione ENTER.";
                getchar();
                break;
            case 2:
                loop = false;
                std::cout << "Pressione ENTER.";
                getchar();
                getchar();
                break;
            default:
                std::cout << "Opcao invalida, prosseguindo o prog." << std::endl;
                loop = false;
                getchar();
                std::cout << "Pressione ENTER.";
                getchar();
                break;
        }    
    }
    
    limpa_tela();
    std::cout << "FIM DO SOFRIMENTO (;--;)." << std:: endl;
    return 0;
}