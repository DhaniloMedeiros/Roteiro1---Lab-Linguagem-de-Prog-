#ifndef CONTROLE_DE_GASTOS_H_INCLUDED
#define CONTROLE_DE_GASTOS_H_INCLUDED
#define TAM 20

#include "Despesa.h"
#include <iostream> 

class ControleDeGastos{
    public:
        //atributos
        Despesa despesas[TAM];
        //construtores
        ControleDeGastos();
        //metodos
        void setDespesas(Despesa d, int pos);
        
        double calculaTotalDeDespesas();    
        bool existeDespesaDoTipo(std::string str);
};
#endif //CONTROLE_DE_GASTOS_H_INCLUDED