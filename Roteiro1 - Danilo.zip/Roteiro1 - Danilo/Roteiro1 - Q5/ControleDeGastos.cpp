#include "ControleDeGastos.h"
#include "Despesa.h"
#include <iostream>
#include <string>

ControleDeGastos::ControleDeGastos(){
    int i;
    for(i = 0; i < TAM; i++){
        despesas[i].valor = 0;
        despesas[i].tipoDeGasto = "NULL";
    }
}
void ControleDeGastos::setDespesas(Despesa d, int pos){
    despesas[pos].valor = d.valor;
    despesas[pos].tipoDeGasto = d.tipoDeGasto;
}
double ControleDeGastos::calculaTotalDeDespesas(){
    int i;
    double valorTotal = 0;
    for(i = 0; i < TAM; i++){
        valorTotal += despesas[i].valor;
    }
    return valorTotal;
}
bool ControleDeGastos::existeDespesaDoTipo(std::string str){
    int i;
    bool find = false;
    for(i = 0; i < TAM; i++){
        if(despesas[i].tipoDeGasto.find(str) != std::string::npos){//achou
            find = true;
            break;
        }
    }
    return find;
}