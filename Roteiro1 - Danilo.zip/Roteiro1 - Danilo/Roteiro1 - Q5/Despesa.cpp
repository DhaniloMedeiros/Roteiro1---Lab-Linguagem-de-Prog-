#include "Despesa.h"
#include <iostream>

Despesa::Despesa(){
    valor = 0;
    tipoDeGasto = "NULL";
}
double Despesa::getValor(){
    return valor;
}
std::string Despesa::getTipoDeGasto(){
    return tipoDeGasto;
}
void Despesa::setValor(double val){
    valor = val;
}
void Despesa::setTipoDeGasto(std::string tdg){
    tipoDeGasto = tdg;
}