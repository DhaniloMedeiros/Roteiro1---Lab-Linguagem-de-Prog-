#include "Pessoa.h"
#include <iostream>

Pessoa::Pessoa(std::string n){
    nome = n;
    idade = 9;
    telefone = "4002-8922";
}

Pessoa::Pessoa(std::string n, int id, std::string tl){
    nome = n;
    idade = id;
    telefone = tl;
}

std::string Pessoa::getNome(){
    return nome;
}

int Pessoa::getIdade(){
    return idade;
}

std::string Pessoa::getTelefone(){
    return telefone;
}

void Pessoa::setNome(std::string n){
    nome = n;
}

void Pessoa::setIdade(int id){
    idade = id;
}

void Pessoa::setTelefone(std::string tl){
    telefone = tl;
}