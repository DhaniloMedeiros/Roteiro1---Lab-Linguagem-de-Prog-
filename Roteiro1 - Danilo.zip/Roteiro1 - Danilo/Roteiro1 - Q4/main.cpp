#include "Pessoa.h"
#include <iostream>

void limpa_tela(void){
    #ifdef __unix__
        system("clear");
    #elif WIN32
        system("cls");
    #endif
}

void menuSetGet(){
    puts("\n~~~~~Utilizar Set e Get~~~~~");
    puts("     1 - Set atributos");
    puts("     2 - Get atributos");
    puts("     3 - Continuar");

    std::cout << "Digite a opcao desejada:";
}

void menuSet(){
    puts("\n~~~~~MENU SET~~~~~");
    puts("   1 - Set nome");
    puts("   2 - Set idade");
    puts("   3 - Set telefone");

    std::cout << "Digite a opcao desejada:";
}

void menuGet(){
    puts("\n~~~~~MENU GET~~~~~");
    puts("   1 - Get nome");
    puts("   2 - Get idade");
    puts("   3 - Get telefone");

    std::cout << "Digite a opcao desejada:";
}

void printPessoa(Pessoa &pes){
    std::cout << "\nNome: " << pes.nome << std::endl;
    std::cout << "Idade: " << pes.idade <<std::endl;
    std::cout << "Telefone: " << pes.telefone << "\n" <<std::endl;
}

int main(){
    Pessoa pessoa1 = Pessoa("Cicrano");
    Pessoa pessoa2 = Pessoa("Fulano", 90, "(84)9-8765-4321");

    bool loop = true;   //var do menu
    int menu1, menu2;

    std::string str; //var pro set e get
    int aux;
    
    std::cout << "Printando pessoa1 com construtor padrao:" << std::endl;
    printPessoa(pessoa1);

    std::cout << "Printando pessoa2 com construtor personalizado:" << std::endl;
    printPessoa(pessoa2);

    std::cout << "Pressione ENTER pra usar set e get no pessoa1:";
    getchar();
    
    while(loop){
        limpa_tela();
        menuSetGet();
        std::cin >> menu1;
        if(menu1 == 1){
            menuSet();
            std::cin >> menu2;
            
            switch(menu2){
                case 1:
                    getchar();
                    std::cout << "Set nome: ";
                    getline(std::cin, str);
                    pessoa1.setNome(str);
                    break;
                case 2:
                    std::cout << "Set idade: ";
                    std::cin >> aux;
                    pessoa1.setIdade(aux);
                    break;
                case 3:
                    getchar();
                    std::cout << "Set telefone: ";
                    getline(std::cin, str);
                    pessoa1.setTelefone(str);
                    break;
                default:
                    loop = false;
                    std::cout << "Numero invalido prosseguindo o programa" << std::endl;
                    break;
            }
        }else if(menu1 == 2){
            menuGet();
            std::cin >> menu2;

            switch(menu2){
                case 1:
                    std::cout << "Get nome: ";
                    str = pessoa1.getNome();
                    std::cout << str << "\n" << std::endl;
                    std::cout << "Press ENTER.";
                    getchar();
                    getchar();
                    break;
                case 2:
                    std::cout << "Get idade: ";
                    aux = pessoa1.getIdade();
                    std::cout << aux << "\n" << std::endl;
                    std::cout << "Press ENTER.";
                    getchar();
                    getchar();
                    break;
                case 3:
                    std::cout << "Get telefone: ";
                    str = pessoa1.getTelefone();
                    std::cout << str << "\n" << std::endl;
                    std::cout << "Press ENTER.";
                    getchar();
                    getchar();
                    break;
                default:
                    loop = false;
                    std::cout << "Numero invalido prosseguindo o programa" << std::endl;
                    break;
            }
        }else{
            loop = false;
            if(menu1 != 3)
                std::cout << "Numero invalido prosseguindo o programa" << std::endl;
        }
    }
    
    limpa_tela();
    std::cout << "Pessoa1 atualizado: " << std::endl;
    printPessoa(pessoa1);

    std::cout << "\nFim do programa." << std::endl;
    return 0;
}