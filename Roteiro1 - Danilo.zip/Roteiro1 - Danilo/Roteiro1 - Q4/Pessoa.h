#ifndef PESSOA_H_INCLUDED
#define PESSOA_H_INCLUDED

#include <iostream> 

class Pessoa{
    public:
        //atributos
        std::string nome;
        int idade;
        std::string telefone;
        //construtores
        Pessoa(std::string n);
        Pessoa(std::string n, int id, std::string tl);
        //metodos
        std::string getNome();
        int getIdade();
        std::string getTelefone();
        void setNome(std::string n);
        void setIdade(int id);
        void setTelefone(std::string tl);
};
#endif //PESSOA_H_INCLUDED
