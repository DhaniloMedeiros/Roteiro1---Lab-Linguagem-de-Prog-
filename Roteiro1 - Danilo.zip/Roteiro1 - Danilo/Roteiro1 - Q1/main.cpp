#include "Data.h"
#include <iostream>

using namespace std;

void print_data(Data &dt){
    cout << dt.dia << "/" << dt.mes << "/" << dt.ano << endl;
}

void print_data_ponteiro(Data *dt){
    cout << dt->dia << "/" << dt->mes << "/" << dt->ano << endl;
}

void limpa_tela(void){
    #ifdef __unix__
        system("clear");
    #elif WIN32
        system("cls");
    #endif
}

void menuSetGet(){
    puts("\n~~~~~Utilizar Set e Get~~~~~");
    puts("     1 - Set atributos");
    puts("     2 - Get atributos");
    puts("     3 - Continuar");

    cout << "Digite a opcao desejada:";
}

void menuGet(){
    puts("\n~~~~~MENU GET~~~~~");
    puts("   1 - Get dia");
    puts("   2 - Get mes");
    puts("   3 - Get ano");

    cout << "Digite a opcao desejada:";
}

void menuSet(){
    puts("\n~~~~~MENU SET~~~~~");
    puts("   1 - Set dia");
    puts("   2 - Set mes");
    puts("   3 - Set ano");

    cout << "Digite a opcao desejada:";
}

int main(){
    Data aniversario = Data();
    Data hoje = Data(13, 11, 2019);
    Data *ontem = new Data(12, 11, 2019);
    Data data_errada = Data(123, 123, -2);
    Data dia_aleatorio;
    Data data_teste = Data(1,1, 2001);
    int teste;
    
    int i, menu;
    bool loopMenu;

    cout << "Aniversario: ";
    print_data(aniversario);
    cout << "Hoje: ";
    print_data(hoje);
    cout << "Ontem: ";
    print_data_ponteiro(ontem);
    cout << "Data errada, corrigida: ";
    print_data(data_errada);

    cout << "\nInforme uma data qualquer." << endl;
    while(1){ 
        
        cout << "Digite o dia:";
        std::cin >> dia_aleatorio.dia;
        cout << "Digite o mes:";
        std::cin >> dia_aleatorio.mes;
        cout << "Digite o ano:";
        std::cin >> dia_aleatorio.ano;

        if(dia_aleatorio.verificarData())
            cout << "Data invalida, tente novamente." << endl;
        else
            break;
    }

    cout << "\nA data digitada foi: ";
    print_data(dia_aleatorio);

    cout << "Pressione ENTER para continuar." << endl;
    getchar();
    getchar();

    limpa_tela();
    loopMenu = true;
    
    cout << "Agora vamos utilizar set e get na data digitada.\n" << endl;
    while(loopMenu){
        int opcao;
        int set, get;
        menuSetGet();
        std::cin >> menu;
        
        switch(menu){
            case 1:
                limpa_tela();
                cout << "Em caso de data invalida, esta sera redefinida automaticamente." << endl;
                menuSet();
                std::cin >> opcao;
                switch(opcao){
                    case 1:
                        cout << "Alterar dia:";
                        std::cin >> set; 
                        dia_aleatorio.setDia(set);
                        break;
                    case 2:
                        cout << "Alterar mes:";
                        std::cin >> set; 
                        dia_aleatorio.setMes(set);
                        break;
                    case 3:
                        cout << "Alterar ano:";
                        std::cin >> set; 
                        dia_aleatorio.setAno(set);
                        break;
                    default:
                        cout << "Opcao invalida, prosseguindo o programa.";
                        loopMenu = false;
                        getchar();
                        std::cout << "\nPressione ENTER.";
                        getchar();
                        break;
                }
                break;
            case 2:
                limpa_tela();
                menuGet();
                std::cin >> opcao;
                switch(opcao){
                    case 1:
                        get = dia_aleatorio.getDia();
                        cout << "Dia: " << get << endl;
                        break;
                    case 2:
                        get = dia_aleatorio.getMes();
                        cout << "Mes: " << get << endl;
                        break;
                    case 3:
                        get = dia_aleatorio.getAno();
                        cout << "Ano: " << get << endl;
                        break;
                    default:
                        cout << "Opcao invalida, prosseguindo o programa.";
                        loopMenu = false;
                        getchar();
                        std::cout << "\nPressione ENTER.";
                        getchar();
                        break;
                }
                break;
            case 3:
                loopMenu = false;
                break;
            default:
                cout << "Opcao invalida, prosseguindo o programa.";
                loopMenu = false;
                getchar();
                std::cout << "\nPressione ENTER.";
                getchar();
                break;
        }
    }
    
    cout << "\nDigite 1 para printar todos os dias do ano, ou 0 para encerrar:" << endl;
    cin >> teste;

    if(teste){
        cout << "\nOs 365 dias serao printados usando o metodo avancarDia!" << endl << "Pressione ENTER para comecar.\n";
        getchar();
        getchar();
        limpa_tela();
        for(i = 0; i < 365; i++){
            print_data(data_teste);
            data_teste.avancarDia();
        }
    }

    cout << "\nO programa chegou ao fim." << endl;

    return 0;
} 