#ifndef DATA_H_INCLUDED
#define DATA_H_INCLUDED

class Data  
{
public:
    //atributos
    int dia, mes, ano;
    //construtores
    Data();
    Data(int d, int m, int a);
    //metodos
    int getDia();
    int getMes();
    int getAno();

    void setDia(int d);
    void setMes(int m);
    void setAno(int a);

    void avancarDia(); 
    int verificarData();
};

#endif //DATA_H_INCLUDED