#include "Pagamento.h"
#include <iostream>

Pagamento::Pagamento(){
    valorPagamento = 0;
    nomeFuncionario = "NULL";
}
double Pagamento::getValorPagamento(){
    return valorPagamento;
}
std::string Pagamento::getNomeFuncionario(){
    return nomeFuncionario;
}
void Pagamento::setValorPagamento(double pg){
    valorPagamento = pg;
}
void Pagamento::setNomeFuncionario(std::string nf){
    nomeFuncionario = nf;
}