#ifndef PAGAMENTO_H_INCLUDED
#define PAGAMENTO_H_INCLUDED

#include <iostream>

class Pagamento
{
    public:
        //atributos
        double valorPagamento;
        std::string nomeFuncionario;
        //construtor
        Pagamento();
        //metodos
        double getValorPagamento();
        std::string getNomeFuncionario();
        void setValorPagamento(double pg);
        void setNomeFuncionario(std::string nf);

};

#endif//PAGAMENTO_H_INCLUDED