#include "Empregado.h"
#include <iostream>

Empregado::Empregado(){
    nome = "Napoleao";
    sobrenome = "Bonaparte";
    salario = 954.00;
}

Empregado::Empregado(std::string n, std::string s, float sl){
    nome = n;
    sobrenome = s;
    salario = sl;
    if(salario < 0)
        salario = 0;
}

std::string Empregado::getNome(){
    return nome;
}

std::string Empregado::getSobrenome(){
    return sobrenome;
}

float Empregado::getSalario(){
    return salario;
}

void Empregado::setNome(std::string n){
    nome = n;
}

void Empregado::setSobreome(std::string s){
    sobrenome = s;
}

void Empregado::setSalario(float sl){
    salario = sl;
    if(salario < 0)
        salario = 0;
}