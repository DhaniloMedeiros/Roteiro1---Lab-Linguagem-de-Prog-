#ifndef EMPREGADO_H_INCLUDED
#define EMPREGADO_H_INCLUDED

#include <iostream> 

class Empregado{
    public:
        //atributos
        std::string nome;
        std::string sobrenome;
        float salario;
        //construtores
        Empregado();
        Empregado(std::string n, std::string s, float sl);
        //metodos
        std::string getNome();
        std::string getSobrenome();
        float getSalario();
        void setNome(std::string n);
        void setSobreome(std::string s);
        void setSalario(float sl);
};
#endif //EMPREGADO_H_INCLUDED