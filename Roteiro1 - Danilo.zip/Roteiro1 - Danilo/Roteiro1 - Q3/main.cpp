#include "Empregado.h"
#include <iostream>

void limpa_tela(void){
    #ifdef __unix__
        system("clear");
    #elif WIN32
        system("cls");
    #endif
}

void menuSetGet(){
    puts("\n~~~~~Utilizar Set e Get~~~~~");
    puts("     1 - Set atributos");
    puts("     2 - Get atributos");
    puts("     3 - Continuar");

    std::cout << "Digite a opcao desejada:";
}

void menuSet(){
    puts("\n~~~~~MENU SET~~~~~");
    puts("   1 - Set nome");
    puts("   2 - Set sobrenome");
    puts("   3 - Set salario");

    std::cout << "Digite a opcao desejada:";
}

void menuGet(){
    puts("\n~~~~~MENU GET~~~~~");
    puts("   1 - Get nome");
    puts("   2 - Get sobrenome");
    puts("   3 - Get salario");

    std::cout << "Digite a opcao desejada:";
}

void printEmpregado(Empregado &emp){
    std::cout << "\nFuncionario: " << emp.nome << " " << emp.sobrenome << std::endl;
    std::cout << "Salario Mensal: R$" << emp.salario << "\n" << std::endl;
}

void printSalarioAnual(Empregado &emp){
    std::cout << "\nFuncionario: " << emp.nome << " " << emp.sobrenome << std::endl;
    std::cout << "Salario Anual: R$" << emp.salario * 12 << "\n" << std::endl;
}

void aumento10(Empregado &emp){
    emp.salario = emp.salario * 1.1;
}

int main(){
    
    Empregado empregado1 = Empregado("Garrosh", "Hellscream", 25000.00);
    Empregado empregado2 = Empregado();
    bool loop = true; //vars menu
    int menu1, menu2;

    std::string str; //vars set e get
    float aux;

    std::cout << "Printando empregado1:" << std::endl;
    printEmpregado(empregado1);

    std::cout << "Printando empregado2:" << std::endl;
    printEmpregado(empregado2);
    
    std::cout << "Testando os Set e Get com o empregado 1" << std::endl;
    std::cout << "Pressione ENTER" << std::endl;
    getchar();
    while(loop){
        limpa_tela();
        menuSetGet();
        std::cin >> menu1;
        
        if(menu1 == 1){
            menuSet();
            std::cin >> menu2;
            
            switch(menu2){
                case 1:
                    std::cout << "Set nome: " << std::endl;
                    getchar();
                    getline(std::cin, str);
                    empregado1.setNome(str);
                    break;
                case 2:
                    std::cout << "Set sobrenome: " << std::endl;
                    getchar();
                    getline(std::cin, str);
                    empregado1.setSobreome(str);
                    break;
                case 3:
                    std::cout << "Set salario: " << std::endl;
                    getchar();
                    std::cin >> aux;
                    empregado1.setSalario(aux);
                    break;
                default:
                std::cout << "Opcao invalida prosseguindo o programa.\n" << std::endl;
                getchar();
                std::cout << "\nPressione ENTER.";
                getchar();
                    break;
            }
        }else if(menu1 == 2){
            menuGet();
            std::cin >> menu2;
            
            switch(menu2){
                case 1:
                    std::cout << "Get nome: ";
                    str = empregado1.getNome();
                    std::cout << str << std::endl;
                    std::cout << "Pressione ENTER" << std::endl;
                    getchar();
                    getchar();
                    break;
                case 2:
                    std::cout << "Get sobrenome: ";
                    str = empregado1.getSobrenome();
                    std::cout << str << std::endl;
                    std::cout << "Pressione ENTER" << std::endl;
                    getchar();
                    getchar();
                    break;
                case 3:
                    std::cout << "Get salario: ";
                    aux = empregado1.getSalario();
                    std::cout << aux << std::endl;
                    std::cout << "Pressione ENTER" << std::endl;
                    getchar();
                    getchar();
                    break;
                default:
                    std::cout << "Opcao invalida prosseguindo o programa.\n" << std::endl;
                    getchar();
                    std::cout << "\nPressione ENTER.";
                    getchar();
                    break;
            }
        }else{
            loop = false;
            if(menu1 != 3)
                std::cout << "Opcao invalida prosseguindo o programa." << std::endl;
        }
    }

    std::cout << "\nPrintando novo empregado1:" << std::endl;
    printEmpregado(empregado1);

    std::cout << "Pressione ENTER para continuar" << std::endl;
    getchar();
    getchar();

    limpa_tela();
    std::cout << "Agora aumento de 10%\n" << std::endl;
    std::cout << "Empregado 1" << std::endl;
    printSalarioAnual(empregado1);

    std::cout << "Empregado 2" << std::endl;
    printSalarioAnual(empregado2);

    aumento10(empregado1);
    aumento10(empregado2);
    std::cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~\n" << std::endl;

    std::cout << "Empregado 1" << std::endl;
    printSalarioAnual(empregado1);

    std::cout << "Empregado 2" << std::endl;
    printSalarioAnual(empregado2);

    std::cout << "Fim de papo meu parceiro." << std::endl;
    return 0;
}